﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.PictureBox4 = New System.Windows.Forms.PictureBox
        Me.PictureBox5 = New System.Windows.Forms.PictureBox
        Me.cmdEasy = New System.Windows.Forms.Button
        Me.cmdMedium = New System.Windows.Forms.Button
        Me.cmdCrazy = New System.Windows.Forms.Button
        Me.cmdQuit = New System.Windows.Forms.Button
        Me.Lable1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblHit = New System.Windows.Forms.Label
        Me.lblAway = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblGameOver = New System.Windows.Forms.Label
        Me.cmdAgain = New System.Windows.Forms.Button
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.Away_game.My.Resources.Resources._16_magenta_balloon
        Me.PictureBox1.Location = New System.Drawing.Point(25, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(103, 88)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = Global.Away_game.My.Resources.Resources._32_silver_balloon
        Me.PictureBox2.Location = New System.Drawing.Point(175, 5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(103, 88)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Image = Global.Away_game.My.Resources.Resources.green_balloon
        Me.PictureBox3.Location = New System.Drawing.Point(325, 5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(103, 88)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.Image = Global.Away_game.My.Resources.Resources.purple_balloon
        Me.PictureBox4.Location = New System.Drawing.Point(475, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(103, 88)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Image = Global.Away_game.My.Resources.Resources._18_sapphire_blue_balloon
        Me.PictureBox5.Location = New System.Drawing.Point(625, 5)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(103, 88)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'cmdEasy
        '
        Me.cmdEasy.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEasy.Location = New System.Drawing.Point(800, 345)
        Me.cmdEasy.Name = "cmdEasy"
        Me.cmdEasy.Size = New System.Drawing.Size(148, 40)
        Me.cmdEasy.TabIndex = 5
        Me.cmdEasy.Text = "EASY"
        Me.cmdEasy.UseVisualStyleBackColor = True
        '
        'cmdMedium
        '
        Me.cmdMedium.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMedium.Location = New System.Drawing.Point(800, 400)
        Me.cmdMedium.Name = "cmdMedium"
        Me.cmdMedium.Size = New System.Drawing.Size(148, 40)
        Me.cmdMedium.TabIndex = 6
        Me.cmdMedium.Text = "MEDIUM"
        Me.cmdMedium.UseVisualStyleBackColor = True
        '
        'cmdCrazy
        '
        Me.cmdCrazy.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCrazy.Location = New System.Drawing.Point(800, 455)
        Me.cmdCrazy.Name = "cmdCrazy"
        Me.cmdCrazy.Size = New System.Drawing.Size(148, 40)
        Me.cmdCrazy.TabIndex = 7
        Me.cmdCrazy.Text = "CRAZY"
        Me.cmdCrazy.UseVisualStyleBackColor = True
        '
        'cmdQuit
        '
        Me.cmdQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdQuit.Location = New System.Drawing.Point(800, 295)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.Size = New System.Drawing.Size(148, 40)
        Me.cmdQuit.TabIndex = 8
        Me.cmdQuit.Text = "QUIT"
        Me.cmdQuit.UseVisualStyleBackColor = True
        '
        'Lable1
        '
        Me.Lable1.AutoSize = True
        Me.Lable1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lable1.Location = New System.Drawing.Point(803, 22)
        Me.Lable1.Name = "Lable1"
        Me.Lable1.Size = New System.Drawing.Size(51, 25)
        Me.Lable1.TabIndex = 9
        Me.Lable1.Text = "HIT:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(803, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 25)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "AWAY:"
        '
        'lblHit
        '
        Me.lblHit.AutoSize = True
        Me.lblHit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHit.Location = New System.Drawing.Point(910, 22)
        Me.lblHit.Name = "lblHit"
        Me.lblHit.Size = New System.Drawing.Size(24, 25)
        Me.lblHit.TabIndex = 11
        Me.lblHit.Text = "0"
        '
        'lblAway
        '
        Me.lblAway.AutoSize = True
        Me.lblAway.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAway.Location = New System.Drawing.Point(910, 59)
        Me.lblAway.Name = "lblAway"
        Me.lblAway.Size = New System.Drawing.Size(24, 25)
        Me.lblAway.TabIndex = 12
        Me.lblAway.Text = "0"
        '
        'Timer1
        '
        '
        'lblGameOver
        '
        Me.lblGameOver.AutoSize = True
        Me.lblGameOver.Font = New System.Drawing.Font("Microsoft Sans Serif", 45.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGameOver.Location = New System.Drawing.Point(239, 257)
        Me.lblGameOver.Name = "lblGameOver"
        Me.lblGameOver.Size = New System.Drawing.Size(393, 69)
        Me.lblGameOver.TabIndex = 13
        Me.lblGameOver.Text = "GAME OVER"
        Me.lblGameOver.Visible = False
        '
        'cmdAgain
        '
        Me.cmdAgain.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAgain.Location = New System.Drawing.Point(800, 510)
        Me.cmdAgain.Name = "cmdAgain"
        Me.cmdAgain.Size = New System.Drawing.Size(148, 40)
        Me.cmdAgain.TabIndex = 1
        Me.cmdAgain.Text = "PLAY AGAIN"
        Me.cmdAgain.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Away_game.My.Resources.Resources.background_image
        Me.ClientSize = New System.Drawing.Size(977, 598)
        Me.Controls.Add(Me.cmdAgain)
        Me.Controls.Add(Me.lblGameOver)
        Me.Controls.Add(Me.lblAway)
        Me.Controls.Add(Me.lblHit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Lable1)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.cmdCrazy)
        Me.Controls.Add(Me.cmdMedium)
        Me.Controls.Add(Me.cmdEasy)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "AWAY GAME"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents cmdEasy As System.Windows.Forms.Button
    Friend WithEvents cmdMedium As System.Windows.Forms.Button
    Friend WithEvents cmdCrazy As System.Windows.Forms.Button
    Friend WithEvents cmdQuit As System.Windows.Forms.Button
    Friend WithEvents Lable1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblHit As System.Windows.Forms.Label
    Friend WithEvents lblAway As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lblGameOver As System.Windows.Forms.Label
    Friend WithEvents cmdAgain As System.Windows.Forms.Button

End Class
